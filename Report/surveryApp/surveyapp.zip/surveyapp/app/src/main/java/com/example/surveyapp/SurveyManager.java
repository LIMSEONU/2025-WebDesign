package com.example.surveyapp;

public class SurveyManager {
    public static int[] answers = new int[10];
}
